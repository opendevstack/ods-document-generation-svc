# ods-document-generation-templates
ODS lifecycle documentation generation - document templates used by the release manager and the [document generation service](https://github.com/opendevstack/ods-document-generation-svc)
